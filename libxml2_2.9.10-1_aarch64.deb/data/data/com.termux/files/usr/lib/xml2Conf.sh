#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/data/data/com.termux/files/usr/lib"
XML2_LIBS="-lxml2 -L/data/data/com.termux/files/usr/lib -lz -L/data/data/com.termux/files/usr/lib -llzma   -liconv  -lm "
XML2_INCLUDEDIR="-I/data/data/com.termux/files/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.10"

