# You have authenticated newsbeuter to access getpocket

Please go back to your terminal (where you started the setup script) and press enter.

After the script is finished you can use the send-to-pocket.sh command to push urls to your getpocket.com account (see the documentation on bookmarks).

Enjoy, Andreas (<andreashappe@snikt.net>)
