% simple dummy predicate to test Zahed's goal from Java:

gen( [t(_,_,_),t(_,_,_)], ok).

