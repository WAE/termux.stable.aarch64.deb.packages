IMPORTED_LINK_INTERFACE_MULTIPLICITY_<CONFIG>
---------------------------------------------

<CONFIG>-specific version of :prop_tgt:`IMPORTED_LINK_INTERFACE_MULTIPLICITY`.

If set, this property completely overrides the generic property for
the named configuration.
