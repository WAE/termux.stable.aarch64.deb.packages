BUNDLE
------

This target is a ``CFBundle`` on the macOS.

If a module library target has this property set to true it will be
built as a ``CFBundle`` when built on the mac.  It will have the directory
structure required for a ``CFBundle`` and will be suitable to be used for
creating Browser Plugins or other application resources.
