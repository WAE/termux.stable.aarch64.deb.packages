HAS_CXX
-------

Link the target using the C++ linker tool (obsolete).

This is equivalent to setting the :prop_tgt:`LINKER_LANGUAGE`
property to ``CXX``.
