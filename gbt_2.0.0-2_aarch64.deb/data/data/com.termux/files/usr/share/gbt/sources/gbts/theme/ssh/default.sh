export GBT_CARS="${GBT__THEME_REMOTE_CARS:=Status, Os, Time, Hostname, Dir, Git, Sign}"

export GBT_CAR_TIME_FORMAT=' {{ Time }} '

export GBT_CAR_HOSTNAME_ADMIN_FG='light_red'
export GBT_CAR_HOSTNAME_USER_FG='light_yellow'
export GBT_CAR_HOSTNAME_HOST_FG='white'
export GBT_CAR_HOSTNAME_HOST_FM='bold'
