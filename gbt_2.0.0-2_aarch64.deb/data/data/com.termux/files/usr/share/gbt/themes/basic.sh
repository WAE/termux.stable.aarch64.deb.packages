export GBT_CARS='Hostname, Dir, Sign'

export GBT_CAR_BG='default'
export GBT_CAR_FG='default'

export GBT_CAR_HOSTNAME_ADMIN_FG='red'
export GBT_CAR_HOSTNAME_FORMAT='{{ UserHost }} '
export GBT_CAR_HOSTNAME_HOST_FM='bold'
export GBT_CAR_HOSTNAME_USER_FM='bold'

export GBT_CAR_DIR_FG='light_blue'
export GBT_CAR_DIR_FORMAT='{{ Dir }}'

export GBT_SEPARATOR=''
