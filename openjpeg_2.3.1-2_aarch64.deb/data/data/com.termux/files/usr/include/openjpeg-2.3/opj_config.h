/* create opj_config.h for CMake */
#define OPJ_HAVE_STDINT_H 		1

/*--------------------------------------------------------------------------*/
/* OpenJPEG Versioning                                                      */

/* Version number. */
#define OPJ_VERSION_MAJOR 2
#define OPJ_VERSION_MINOR 3
#define OPJ_VERSION_BUILD 1
