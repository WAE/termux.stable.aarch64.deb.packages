# /usr/share/abuild/functions.sh

sysconfdir=/data/data/com.termux/files/usr/etc
program=${0##*/}

arch_to_hostspec() {
	case "$1" in
	aarch64)    echo "aarch64-linux-android" ;;
	arm)        echo "arm-linux-androideabi" ;;
	i686)       echo "i686-linux-android" ;;
	x86_64)     echo "x86_64-linux-android" ;;
	*)		echo "unknown" ;;
	esac
}

hostspec_to_arch() {
	case "$1" in
	aarch64-*)  echo "aarch64" ;;
	arm-*)      echo "arm" ;;
	i686-*)     echo "i686" ;;
	x86_64-*)   echo "x86_64" ;;
	*)			echo "unknown" ;;
	esac
}

hostspec_to_libc() {
	case "$1" in
	*-*-*-uclibc*)	echo "uclibc" ;;
	*-*-*-musl*)	echo "musl" ;;
	*-*-*-gnu*)	echo "glibc" ;;
	*)		echo "unknown" ;;
	esac
}

readconfig() {
	local _APORTSDIR _BUILDDIR _PKGDEST _SRCPKGDEST _REPODEST _SRCDEST
	local _CARCH _CHOST _CTARGET _CPPFLAGS _CFLAGS _CXXFLAGS _LDFLAGS
	local _JOBS _MAKEFLAGS _PACKAGER _USE_COLORS
	local gitbase=
	[ -n "${APORTSDIR+x}" ] && _APORTSDIR=$APORTSDIR
	[ -n "${BUILDDIR+x}" ] && _BUILDDIR=$BUILDDIR
	[ -n "${PKGDEST+x}" ] && _PKGDEST=$PKGDEST
	[ -n "${SRCPKGDEST+x}" ] && _SRCPKGDEST=$SRCPKGDEST
	[ -n "${REPODEST+x}" ] && _REPODEST=$REPODEST
	[ -n "${SRCDEST+x}" ] && _SRCDEST=$SRCDEST
	[ -n "${CARCH+x}" ] && _CARCH=$CARCH
	[ -n "${CHOST+x}" ] && _CHOST=$CHOST
	[ -n "${CTARGET+x}" ] && _CTARGET=$CTARGET
	[ -n "${CPPFLAGS+x}" ] && _CPPFLAGS=$CPPFLAGS
	[ -n "${CFLAGS+x}" ] && _CFLAGS=$CFLAGS
	[ -n "${CXXFLAGS+x}" ] && _CXXFLAGS=$CXXFLAGS
	[ -n "${LDFLAGS+x}" ] && _LDFLAGS=$LDFLAGS
	[ -n "${JOBS+x}" ] && _JOBS=$JOBS
	[ -n "${MAKEFLAGS+x}" ] && _MAKEFLAGS=$MAKEFLAGS
	[ -n "${PACKAGER+x}" ] && _PACKAGER=$PACKAGER
	[ -n "${USE_COLORS+x}" ] && _USE_COLORS="$USE_COLORS"
	: ${ABUILD_CONF:=$sysconfdir/abuild.conf}
	: ${ABUILD_USERDIR:=$HOME/.abuild}
	: ${ABUILD_USERCONF:=$ABUILD_USERDIR/abuild.conf}
	[ -f "$ABUILD_CONF" ] && . "$ABUILD_CONF"
	[ -f "$ABUILD_USERCONF" ] && . "$ABUILD_USERCONF"
	APORTSDIR=${_APORTSDIR-$APORTSDIR}
	gitbase=$(git rev-parse --show-toplevel 2>/dev/null) || true # already is -P
	if [ -d "$APORTSDIR" ]; then
		APORTSDIR=$(cd "$APORTSDIR"; pwd -P)
	elif [ -z "$APORTSDIR" ] && [ -d "$HOME/aports" ]; then
		APORTSDIR=$(cd "$HOME/aports"; pwd -P)
	else
		if [ -n "$gitbase" ]; then
			case $(git config remote.origin.url) in
			*/aports) APORTSDIR=$gitbase ;;
			*) APORTSDIR= ;;
			esac
		else
			APORTSDIR=
		fi
	fi
	# source any .abuild file at the aports root, but only if we are currently in aports tree
	[ -n "$APORTSDIR" ] && [ -f "$APORTSDIR/.abuild" ] && [ "$APORTSDIR" = "$gitbase" ] && . "$APORTSDIR/.abuild"
	BUILDDIR=${_BUILDDIR-$BUILDDIR}
	PKGDEST=${_PKGDEST-$PKGDEST}
	SRCPKGDEST=${_SRCPKGDEST-$SRCPKGDEST}
	REPODEST=${_REPODEST-$REPODEST}
	SRCDEST=${_SRCDEST-$SRCDEST}
	CARCH=${_CARCH-$CARCH}
	CHOST=${_CHOST-$CHOST}
	CTARGET=${_CTARGET-$CTARGET}
	CPPFLAGS=${_CPPFLAGS-$CPPFLAGS}
	CFLAGS=${_CFLAGS-$CFLAGS}
	CXXFLAGS=${_CXXFLAGS-$CXXFLAGS}
	LDFLAGS=${_LDFLAGS-$LDFLAGS}
	JOBS=${_JOBS-$JOBS}
	MAKEFLAGS=${_MAKEFLAGS-$MAKEFLAGS}
	PACKAGER=${_PACKAGER-$PACKAGER}
	USE_COLORS=${_USE_COLORS-$USE_COLORS}

	[ -z "$CBUILD" ] && CBUILD="$(clang -dumpmachine)"
	[ -z "$CHOST" ] && CHOST="$CBUILD"
	[ -z "$CTARGET" ] && CTARGET="$CHOST"
	[ "$(arch_to_hostspec $CBUILD)" != "unknown" ] && CBUILD="$(arch_to_hostspec $CBUILD)"
	[ "$(arch_to_hostspec $CHOST)" != "unknown" ] && CHOST="$(arch_to_hostspec $CHOST)"
	[ "$(arch_to_hostspec $CTARGET)" != "unknown" ] && CTARGET="$(arch_to_hostspec $CTARGET)"

	[ -z "$CARCH" ] && CARCH="$(hostspec_to_arch $CHOST)"
	[ -z "$CLIBC" ] && CLIBC="$(hostspec_to_libc $CHOST)"
	[ -z "$CBUILD_ARCH" ] && CBUILD_ARCH="$(hostspec_to_arch $CBUILD)"
	[ -z "$CTARGET_ARCH" ] && CTARGET_ARCH="$(hostspec_to_arch $CTARGET)"
	[ -z "$CTARGET_LIBC" ] && CTARGET_LIBC="$(hostspec_to_libc $CTARGET)"

	if [ "$CHOST" != "$CTARGET" ]; then
		# setup environment for creating cross compiler
		[ -z "$CBUILDROOT" ] && export CBUILDROOT="$HOME/sysroot-$CTARGET_ARCH/"
	elif [ "$CBUILD" != "$CHOST" ]; then
		# setup build root
		[ -z "$CBUILDROOT" ] && export CBUILDROOT="$HOME/sysroot-$CTARGET_ARCH/"
		# prepare pkg-config for cross building
		[ -z "$PKG_CONFIG_PATH" ] && export PKG_CONFIG_PATH="${CBUILDROOT}/lib/pkgconfig/"
		[ -z "$PKG_CONFIG_SYSROOT_DIR" ] && export PKG_CONFIG_SYSROOT_DIR="${CBUILDROOT}"

		# libtool bug workaround for extra rpaths
		if [ -z "$lt_cv_sys_lib_dlsearch_path_spec" ]; then
			case $CTARGET_ARCH in
			aarch64|x86_64) export lt_cv_sys_lib_dlsearch_path_spec="${CBUILDROOT}/lib /data/data/com.termux/files/usr/lib /system/lib64" ;;
			*) export lt_cv_sys_lib_dlsearch_path_spec="${CBUILDROOT}/lib /data/data/com.termux/files/usr/lib /system/lib" ;;
			esac
		fi

		# Originally set in build-package.sh script in Termux build environment.
		# https://github.com/termux/termux-packages/blob/master/build-package.sh
		export ac_cv_func_getpwent=no
		export ac_cv_func_getpwnam=no
		export ac_cv_func_getpwuid=no
		export ac_cv_func_sigsetmask=no
		export ac_cv_c_bigendian=no
		export ac_cv_func_calloc_0_nonnull=yes
		export ac_cv_func_calloc_0_nonnull=yes
		export ac_cv_func_chown_works=yes
		export ac_cv_func_getgroups_works=yes
		export ac_cv_func_malloc_0_nonnull=yes
		export ac_cv_func_realloc_0_nonnull=yes
		export am_cv_func_working_getline=yes
		export gl_cv_C_locale_sans_EILSEQ=yes
		export gl_cv_func_dup2_works=yes
		export gl_cv_func_fcntl_f_dupfd_cloexec=yes
		export gl_cv_func_fcntl_f_dupfd_works=yes
		export gl_cv_func_fnmatch_posix=yes
		export gl_cv_func_getcwd_abort_bug=no
		export gl_cv_func_getcwd_null=yes
		export gl_cv_func_getcwd_path_max=yes
		export gl_cv_func_getcwd_posix_signature=yes
		export gl_cv_func_gettimeofday_clobber=no
		export gl_cv_func_gettimeofday_posix_signature=yes
		export gl_cv_func_link_works=yes
		export gl_cv_func_lstat_dereferences_slashed_symlink=yes
		export gl_cv_func_malloc_0_nonnull=yes
		export gl_cv_func_memchr_works=yes
		export gl_cv_func_mkdir_trailing_dot_works=yes
		export gl_cv_func_mkdir_trailing_slash_works=yes
		export gl_cv_func_mkfifo_works=yes
		export gl_cv_func_mknod_works=yes
		export gl_cv_func_realpath_works=yes
		export gl_cv_func_select_detects_ebadf=yes
		export gl_cv_func_snprintf_posix=yes
		export gl_cv_func_snprintf_retval_c99=yes
		export gl_cv_func_snprintf_truncation_c99=yes
		export gl_cv_func_stat_dir_slash=yes
		export gl_cv_func_stat_file_slash=yes
		export gl_cv_func_strerror_0_works=yes
		export gl_cv_func_symlink_works=yes
		export gl_cv_func_tzset_clobber=no
		export gl_cv_func_unlink_honors_slashes=yes
		export gl_cv_func_unlink_honors_slashes=yes
		export gl_cv_func_vsnprintf_posix=yes
		export gl_cv_func_vsnprintf_zerosize_c99=yes
		export gl_cv_func_wcwidth_works=yes
		export gl_cv_func_working_getdelim=yes
		export gl_cv_func_working_mkstemp=yes
		export gl_cv_func_working_mktime=yes
		export gl_cv_func_working_strerror=yes
		export gl_cv_header_working_fcntl_h=yes

		# setup cross-compiler
		if [ -z "$CROSS_COMPILE" ]; then
			export CROSS_COMPILE="${CHOST}-"
			export HOSTCC="$CC"
			export HOSTCXX="$CXX"
			export HOSTLD="$LD"
			export HOSTCPPFLAGS="$CPPFLAGS"
			export HOSTCXXFLAGS="$CXXFLAGS"
			export HOSTCFLAGS="$CFLAGS"
			export HOSTLDFLAGS="$LDFLAGS"
			export CC=${CROSS_COMPILE}clang
			export CXX=${CROSS_COMPILE}clang++
			export LD=${CROSS_COMPILE}ld
			export CPPFLAGS="--sysroot=${CBUILDROOT} $CPPFLAGS"
			export CXXFLAGS="--sysroot=${CBUILDROOT} $CXXFLAGS"
			export CFLAGS="--sysroot=${CBUILDROOT} $CFLAGS"
			export LDFLAGS="--sysroot=${CBUILDROOT} $LDFLAGS"
		fi
	fi
	return 0
}
readconfig

# expects $1 to be a package directory in the aports tree ('foo' or 'main/foo')
# outputs APKBUILD's path if successful
aports_buildscript() {
	[ -n "$APORTSDIR" ] || return 1
	if [ "${1#*/}" != "$1" ]; then
		( cd "$APORTSDIR/$1" && [ -f APKBUILD ] && echo "$PWD/APKBUILD" )
	else
		( cd "$APORTSDIR"/*/"$1" && [ -f APKBUILD ] && echo "$PWD/APKBUILD" )
	fi
}

# expects $1 to be a file, or a directory containing an APKBUILD, or a package directory in the aports tree
# outputs APKBUILD's path if successful (doesn't verify that it's a valid APKBUILD)
any_buildscript() {
	if [ -f "$1" ]; then
		echo "$1"
	elif [ -d "$1" ]; then
		[ -f "$1/APKBUILD" ] || return 1
		echo "$1/APKBUILD"
	else
		aports_buildscript "$1" || return 1
	fi
}

# output functions
msg() {
	[ -n "$quiet" ] && return 0
	local prompt="$GREEN>>>${NORMAL}"
	printf "${prompt} %s\n" "$1" >&2
}

msg2() {
	[ -n "$quiet" ] && return 0
	#      ">>> %s"
	printf "    %s\n" "$1" >&2
}

warning() {
	local prompt="${YELLOW}>>> WARNING:${NORMAL}"
	printf "${prompt} %s\n" "$1" >&2
}

warning2() {
	#      ">>> WARNING: %s\n"
	printf "             %s\n" "$1" >&2
}

error() {
	local prompt="${RED}>>> ERROR:${NORMAL}"
	printf "${prompt} %s\n" "$1" >&2
}

error2() {
	#      ">>> ERROR:
	printf "           %s\n" "$1" >&2
}

set_xterm_title() {
	if [ "$TERM" = xterm ] && [ -n "$USE_COLORS" ]; then
		 printf "\033]0;$1\007" >&2
	fi
}

disable_colors() {
	NORMAL=""
	STRONG=""
	RED=""
	GREEN=""
	YELLOW=""
	BLUE=""
}

enable_colors() {
	NORMAL="\033[1;0m"
	STRONG="\033[1;1m"
	RED="\033[1;31m"
	GREEN="\033[1;32m"
	YELLOW="\033[1;33m"
	BLUE="\033[1;34m"
}

if [ "$USE_COLORS" = force ]; then
	enable_colors
elif [ -n "$USE_COLORS" ] && [ -t 1 ]; then
	enable_colors
else
	disable_colors
fi

# caller may override
cleanup() {
	return 0
}

die() {
	error "$@"
	cleanup
	exit 1
}
