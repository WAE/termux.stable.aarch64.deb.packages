#ifndef __CHANNEL_EVENTS_H
#define __CHANNEL_EVENTS_H

#include "irc.h"

void channel_events_init(void);
void channel_events_deinit(void);

#endif
