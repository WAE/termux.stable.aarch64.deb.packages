#ifndef __FE_SETTINGS_H
#define __FE_SETTINGS_H

void fe_settings_set_print(const char *key);

#endif
