This directory contains sample scripts to interact with aria2 via
XML-RPC. For more information, see
https://aria2.github.io/manual/en/html/aria2c.html#rpc-interface
