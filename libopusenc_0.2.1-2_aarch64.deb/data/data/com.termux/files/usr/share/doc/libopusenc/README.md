# Libopusenc

[![Travis Build Status](https://travis-ci.org/xiph/libopusenc.svg?branch=master)](https://travis-ci.org/xiph/libopusenc)

The libopusenc libraries provide a high-level API for
encoding .opus files. libopusenc depends only on libopus.

The library is in very early development.
Please give feedback
in #opus on irc.freenode.net or at opus@xiph.org.

Programming documentation is available in tree and online at
https://opus-codec.org/docs/
